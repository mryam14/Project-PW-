<?php
    include_once "formPasien.php";
    include_once "pasien.php";
?>